#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lightweight PCA + MLP model for the CYPHER 2026 dynamic ROM challenge.

Architecture:
  1. MinMax scaling per-feature (evita problemi con campi a scale diverse)
  2. PCA (truncatedSVD) per ridurre (n_cells * n_features) -> N_MODES
  3. MLP leggero che predice delta_q = q_{t+1} - q_t (residual learning,
     converge prima e generalizza meglio rispetto a predire q_{t+1} diretto)
     Input:  [q_t (N_MODES), phi_t (1), phi_{t+1} (1)]
     Output: delta_q (N_MODES)
  4. Roll-forward autoregressivo al momento di predict()

RAM: il collo di bottiglia è la SVD. Con N_MODES=16 e 2 simulazioni da
(110000, 2001), la matrice concatenata è ~110k x 4002 float32 ≈ 1.7 GB.
La SVD randomizzata (sklearn) ne tiene in memoria ~3-4x -> ~5-7 GB picco.
Riduci N_MODES o SUBSAMPLE_T se hai meno RAM disponibile.
"""

import os
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from sklearn.utils.extmath import randomized_svd
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler

from utils import list_training_simulations, load_simulation, load_test_simulation


# ── Iperparametri ────────────────────────────────────────────────────────────
N_MODES      = 8      # numero di modi PCA; aumenta per piu accuratezza (ma piu RAM)
SUBSAMPLE_T  = 2       # prendi 1 snapshot ogni SUBSAMPLE_T per costruire la base PCA
                       # (1 = tutti i timestep, 2 = meta, ecc.) — non tocca il training MLP
MLP_LAYERS   = (128, 64)   # neuroni per layer nascosto
MLP_ITER     = 200         # iterazioni massime Adam
RANDOM_STATE = 42
# ─────────────────────────────────────────────────────────────────────────────


class model:

    def __init__(self):
        self.f_min  = None   # (n_rows,)  scaler minmax
        self.f_max  = None
        self.Phi    = None   # (n_rows, N_MODES)  base PCA
        self.scaler = None   # StandardScaler sulle feature MLP
        self.net    = None   # MLPRegressor

    # ── 1. preprocess ────────────────────────────────────────────────────────

    def preprocess(self, data_folder):
        """
        Carica tutte le simulazioni di training e costruisce:
          - lo scaler minmax (per-feature)
          - la base PCA (randomized SVD)
          - le coppie supervisionate (input MLP, target delta_q)

        Ritorna un dict D con le coppie già pronte per fit().
        """
        states, phis = [], []
        for sim_name in list_training_simulations(data_folder):
            state, phi = load_simulation(os.path.join(data_folder, sim_name))
            states.append(state.astype(np.float32))
            phis.append(phi.astype(np.float32))
            print(f"[PREPROCESS] {sim_name}: state={state.shape}, phi={phi.shape}")

        # --- MinMax scaling per-feature (su tutti i timestep di training) ---
        all_states = np.concatenate(states, axis=1)   # (n_rows, total_t)
        self.f_min = all_states.min(axis=1)
        self.f_max = all_states.max(axis=1)
        denom = self.f_max - self.f_min
        denom[denom == 0.0] = 1.0
        self.denom = denom
        del all_states

        # --- Scala ogni simulazione ---
        scaled = []
        for s in states:
            scaled.append((s - self.f_min[:, None]) / self.denom[:, None])

        # --- PCA tramite SVD randomizzata ---
        # Sottocampiona il tempo per ridurre il picco di RAM
        snap_list = [s[:, ::SUBSAMPLE_T] for s in scaled]
        S = np.concatenate(snap_list, axis=1).astype(np.float32)
        print(f"[PREPROCESS] SVD su matrice {S.shape} ...")
        U, _, _ = randomized_svd(S, n_components=N_MODES, n_iter=4,
                                 random_state=RANDOM_STATE)
        self.Phi = U.astype(np.float32)   # (n_rows, N_MODES)
        del S, snap_list
        print(f"[PREPROCESS] Base PCA: {self.Phi.shape}")

        # --- Costruisce coppie (q_t, phi_t, phi_{t+1}) -> delta_q ---
        X_list, Y_list = [], []
        for s_scaled, phi in zip(scaled, phis):
            q = (self.Phi.T @ s_scaled).T   # (n_t, N_MODES)
            q_t   = q[:-1]                  # (n_t-1, N_MODES)
            dq    = q[1:] - q[:-1]          # target: delta nel spazio ridotto
            phi_t   = phi[:-1, None]        # (n_t-1, 1)
            phi_tp1 = phi[1:,  None]        # (n_t-1, 1)
            X = np.hstack([q_t, phi_t, phi_tp1])   # (n_t-1, N_MODES+2)
            X_list.append(X.astype(np.float32))
            Y_list.append(dq.astype(np.float32))

        X_all = np.vstack(X_list)
        Y_all = np.vstack(Y_list)
        print(f"[PREPROCESS] Coppie supervisionate: X={X_all.shape}, Y={Y_all.shape}")
        return {"X": X_all, "Y": Y_all}

    # ── 2. fit ───────────────────────────────────────────────────────────────

    def fit(self, D):
        """Standardizza le feature e addestra l'MLP."""
        X, Y = D["X"], D["Y"]

        self.scaler = StandardScaler()
        X_sc = self.scaler.fit_transform(X)

        self.net = MLPRegressor(
            hidden_layer_sizes=MLP_LAYERS,
            activation='relu',
            solver='adam',
            max_iter=MLP_ITER,
            random_state=RANDOM_STATE,
            verbose=True,
            n_iter_no_change=20,
            tol=1e-5,
        )
        print(f"[FIT] Training MLP {MLP_LAYERS} su {X_sc.shape[0]} campioni ...")
        self.net.fit(X_sc, Y)
        print(f"[FIT] MLP addestrato in {self.net.n_iter_} iterazioni.")

    # ── 3. predict ───────────────────────────────────────────────────────────

    def predict(self, test_data_folder):
        """
        Roll-forward autoregressivo nello spazio PCA.

        Legge initial_state.npz e phi.npz dalla cartella del test,
        ritorna state_pred di shape (n_rows, n_timesteps).
        """
        initial_state, phi = load_test_simulation(test_data_folder)
        initial_state = initial_state.astype(np.float32)
        phi = phi.astype(np.float32)
        n_timesteps = len(phi)
        n_rows = initial_state.shape[0]

        # --- Scala e proietta lo stato iniziale ---
        s0_sc = (initial_state - self.f_min) / self.denom   # (n_rows,)
        q = self.Phi.T @ s0_sc                               # (N_MODES,)

        # --- Roll-forward ---
        Q_pred = np.zeros((n_timesteps, N_MODES), dtype=np.float32)
        Q_pred[0] = q

        for t in range(n_timesteps - 1):
            x = np.hstack([Q_pred[t], phi[t], phi[t + 1]]).reshape(1, -1)
            x_sc = self.scaler.transform(x)
            dq = self.net.predict(x_sc)[0]
            Q_pred[t + 1] = Q_pred[t] + dq   # residual: somma il delta

        # --- Ricostruisce nello spazio fisico e de-scala ---
        state_pred = self.Phi @ Q_pred.T   # (n_rows, n_timesteps)
        state_pred = state_pred * self.denom[:, None] + self.f_min[:, None]

        return state_pred.astype(np.float32)