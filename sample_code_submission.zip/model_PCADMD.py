#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DMDc (DMD with control) model for the CYPHER 2026 dynamic ROM challenge.

Principio: phi(t) + phi(t+1) + field(t) -> field(t+1)

Architettura:
  1. MinMax scaling per-feature
  2. PCA: riduce field (n_rows,) -> q (N_MODES,)
  3. DMDc: impara A, B tali che  q_{t+1} = A @ q_t + B @ [phi_t, phi_{t+1}]
     fit via regressione ai minimi quadrati (lstsq), nessuna libreria esterna
  4. predict: roll-forward con q_{t+1} = A @ q_t + B @ [phi_t, phi_{t+1}]
     poi ricostruisce nello spazio fisico e de-scala

Dipendenze: solo numpy + sklearn (già nel Docker della challenge).
"""

import os
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from sklearn.utils.extmath import randomized_svd

from utils import list_training_simulations, load_simulation, load_test_simulation


# ── Iperparametri ────────────────────────────────────────────────────────────
N_MODES     = 8    # modi PCA; aumenta per più accuratezza (più RAM)
SUBSAMPLE_T = 2     # 1 = tutti i timestep per la SVD, 2 = uno ogni due, ecc.
# ─────────────────────────────────────────────────────────────────────────────


class model:

    def __init__(self):
        self.f_min = None   # (n_rows,)
        self.denom = None   # (n_rows,)  f_max - f_min, con 0->1
        self.Phi   = None   # (n_rows, N_MODES)  base PCA
        self.A     = None   # (N_MODES, N_MODES)  matrice di stato DMDc
        self.B     = None   # (N_MODES, 2)         matrice di ingresso DMDc

    # ── 1. preprocess ────────────────────────────────────────────────────────

    def preprocess(self, data_folder):
        """
        Carica le simulazioni di training, calcola scaler + base PCA,
        e assembla le matrici per il fit DMDc.

        Ritorna D = {"Q_now": ..., "Q_next": ..., "U": ...}
          Q_now  (N_MODES, total_pairs)  stati correnti nello spazio ridotto
          Q_next (N_MODES, total_pairs)  stati successivi
          U      (2,       total_pairs)  ingressi [phi_t, phi_{t+1}]
        """
        states, phis = [], []
        for sim_name in list_training_simulations(data_folder):
            state, phi = load_simulation(os.path.join(data_folder, sim_name))
            states.append(state.astype(np.float32))
            phis.append(phi.astype(np.float32))
            print(f"[PREPROCESS] {sim_name}: state={state.shape}, phi={phi.shape}")

        # --- MinMax scaling ---
        all_states = np.concatenate(states, axis=1)
        self.f_min = all_states.min(axis=1)
        denom = all_states.max(axis=1) - self.f_min
        denom[denom == 0.0] = 1.0
        self.denom = denom
        del all_states

        scaled = [(s - self.f_min[:, None]) / self.denom[:, None] for s in states]

        # --- PCA via SVD randomizzata ---
        snap_sub = [s[:, ::SUBSAMPLE_T] for s in scaled]
        S = np.concatenate(snap_sub, axis=1).astype(np.float32)
        print(f"[PREPROCESS] SVD su matrice {S.shape} ...")
        U_svd, _, _ = randomized_svd(S, n_components=N_MODES,
                                     n_iter=4, random_state=42)
        self.Phi = U_svd.astype(np.float32)   # (n_rows, N_MODES)
        del S, snap_sub
        print(f"[PREPROCESS] Base PCA: {self.Phi.shape}")

        # --- Costruisce coppie per DMDc ---
        # q_{t+1} = A @ q_t + B @ [phi_t, phi_{t+1}]
        Q_now_list, Q_next_list, U_list = [], [], []
        for s_sc, phi in zip(scaled, phis):
            q = self.Phi.T @ s_sc              # (N_MODES, n_t)
            Q_now_list.append(q[:, :-1])       # (N_MODES, n_t-1)
            Q_next_list.append(q[:, 1:])       # (N_MODES, n_t-1)
            u = np.vstack([phi[:-1], phi[1:]]) # (2, n_t-1)
            U_list.append(u)

        return {
            "Q_now":  np.concatenate(Q_now_list,  axis=1).astype(np.float32),
            "Q_next": np.concatenate(Q_next_list, axis=1).astype(np.float32),
            "U":      np.concatenate(U_list,      axis=1).astype(np.float32),
        }

    # ── 2. fit ───────────────────────────────────────────────────────────────

    def fit(self, D):
        """
        Risolve  Q_next = [A | B] @ [Q_now; U]  ai minimi quadrati.

        [A | B] ha shape (N_MODES, N_MODES + 2).
        Si risolve con numpy.linalg.lstsq su ogni riga (o in blocco).
        """
        Q_now  = D["Q_now"]   # (N_MODES, M)
        Q_next = D["Q_next"]  # (N_MODES, M)
        U      = D["U"]       # (2, M)

        # Matrice regressore: [q_t; phi_t; phi_{t+1}] di shape (N_MODES+2, M)
        Omega = np.vstack([Q_now, U]).astype(np.float64)   # float64 per lstsq

        # Risolve Q_next = AB @ Omega  ->  AB = Q_next @ Omega^+
        # lstsq risolve per ogni riga di Q_next contemporaneamente
        AB, _, _, _ = np.linalg.lstsq(Omega.T, Q_next.T.astype(np.float64),
                                       rcond=None)
        AB = AB.T.astype(np.float32)   # (N_MODES, N_MODES+2)

        self.A = AB[:, :N_MODES]       # (N_MODES, N_MODES)
        self.B = AB[:, N_MODES:]       # (N_MODES, 2)

        print(f"[FIT] A={self.A.shape}, B={self.B.shape}  — DMDc completato.")

    # ── 3. predict ───────────────────────────────────────────────────────────

    def predict(self, test_data_folder):
        """Roll-forward:  q_{t+1} = A @ q_t + B @ [phi_t, phi_{t+1}]"""
        initial_state, phi = load_test_simulation(test_data_folder)
        initial_state = initial_state.astype(np.float32)
        phi = phi.astype(np.float32)
        n_t = len(phi)

        # Scala e proietta lo stato iniziale
        s0_sc = (initial_state - self.f_min) / self.denom
        q = self.Phi.T @ s0_sc   # (N_MODES,)

        # Roll-forward
        Q_pred = np.zeros((N_MODES, n_t), dtype=np.float32)
        Q_pred[:, 0] = q
        for t in range(n_t - 1):
            u_t = np.array([phi[t], phi[t + 1]], dtype=np.float32)
            Q_pred[:, t + 1] = self.A @ Q_pred[:, t] + self.B @ u_t

        # Ricostruisce e de-scala
        state_pred = self.Phi @ Q_pred   # (n_rows, n_t)
        state_pred = state_pred * self.denom[:, None] + self.f_min[:, None]

        return state_pred.astype(np.float32)