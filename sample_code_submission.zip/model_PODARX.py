#!/usr/bin/env python3
"""
POD-ARX model for the CYPHER 2026 dynamic ROM challenge.

Architecture (from handoff_sum_sin_cut):
  - Preprocessing : minmax scaling per feature (species_minmax)
  - Dimensionality reduction : POD via truncated SVD  (n_modes = 8)
  - Dynamics       : MIMO-ARX in the reduced space    (na=5, nb=1, nk=1)
  - Prediction     : free-run simulation with warm-start from the initial snapshot

The class exposes the three methods required by the ingestion program:
    preprocess(data_folder)  ->  D
    fit(D)                   ->  None
    predict(test_data_folder)->  np.ndarray  shape (n_features * n_cells, n_timesteps)
"""

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
from sklearn.utils.extmath import randomized_svd
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import PolynomialFeatures


# ---------------------------------------------------------------------------
# MIMO-ARX (unchanged from handoff code)
# ---------------------------------------------------------------------------

class SimpleMIMOARX:
    """
    MIMO Auto-Regressive model with eXogenous input.

    Predicts n_outputs scalar time series given a scalar forcing signal u(t).
    Each output mode is fitted with its own linear (or Ridge) regression.
    """

    def __init__(
        self,
        na=5,
        nb=1,
        nk=1,
        n_outputs=8,
        high_order_modes=None,
        use_ridge=False,
        alpha=0.0,
        per_mode_alpha=None,
        poly_degree=1,
    ):
        self.na = int(na)
        self.nb = int(nb)
        self.nk = int(nk)
        self.n_outputs = int(n_outputs)
        self.high_order_modes = set(high_order_modes or [])
        self.use_ridge = bool(use_ridge)
        self.alpha = float(alpha)
        self.per_mode_alpha = per_mode_alpha
        self.poly_degree = int(poly_degree)
        self.models = {}
        self.poly_transformers = {}
        self.is_fitted = False
        self.max_delay = None
        self._y_min = None
        self._y_max = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_na_for_mode(self, mode_idx):
        return self.na + 4 if mode_idx in self.high_order_modes else self.na

    def _build_regressor_matrix(self, u, Y, target_mode):
        u = np.asarray(u)
        Y = np.asarray(Y)
        min_len = min(len(u), Y.shape[0])
        u = u[:min_len]
        Y = Y[:min_len, :]
        na_target = self._get_na_for_mode(target_mode)
        max_delay = max(na_target, self.nb + self.nk - 1)
        n = len(u)
        n_valid = n - max_delay
        n_reg = na_target * self.n_outputs + self.nb
        X = np.zeros((n_valid, n_reg))
        for i in range(n_valid):
            t = i + max_delay
            r = 0
            for out_idx in range(self.n_outputs):
                for j in range(na_target):
                    X[i, r] = Y[t - 1 - j, out_idx]
                    r += 1
            for j in range(self.nb):
                X[i, r] = u[t - self.nk - j]
                r += 1
        return X, max_delay

    def _get_alpha_for_mode(self, mode_idx):
        if self.per_mode_alpha is not None:
            return float(self.per_mode_alpha[mode_idx])
        return self.alpha

    def _transform_poly(self, X, mode_idx, fit=False):
        if self.poly_degree <= 1:
            return X
        if fit:
            poly = PolynomialFeatures(degree=self.poly_degree, include_bias=False)
            X_poly = poly.fit_transform(X)
            self.poly_transformers[mode_idx] = poly
            return X_poly
        return self.poly_transformers[mode_idx].transform(X)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, u, Y):
        """
        Fit one regression model per output mode.

        Parameters
        ----------
        u : array (n_timesteps,)     – scalar forcing signal
        Y : array (n_timesteps, n_outputs) – reduced-space coordinates
        """
        Y = np.asarray(Y)
        max_delays = []
        for out_idx in range(self.n_outputs):
            X, delay = self._build_regressor_matrix(u, Y, out_idx)
            X = self._transform_poly(X, out_idx, fit=True)
            y = Y[delay:, out_idx]
            a = self._get_alpha_for_mode(out_idx)
            model = Ridge(alpha=a) if self.use_ridge else LinearRegression()
            model.fit(X, y)
            self.models[out_idx] = model
            max_delays.append(delay)
            print(f"[ARX FIT] Mode {out_idx+1}/{self.n_outputs} fitted")
        self.max_delay = int(max(max_delays))
        self.is_fitted = True
        self._y_min = Y.min(axis=0)
        self._y_max = Y.max(axis=0)
        return self

    def predict_sim(self, u, Y_init=None):
        """
        Free-run (autonomous) simulation.

        Parameters
        ----------
        u      : array (n_timesteps,)
        Y_init : array (max_delay, n_outputs) or None
                 If provided, used to seed the simulation buffer.

        Returns
        -------
        Y_pred : array (n_timesteps, n_outputs)
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted.")
        u = np.asarray(u)
        n = len(u)
        Y_pred = np.zeros((n, self.n_outputs))

        # seed buffer with warm-start data
        if Y_init is not None:
            k0 = min(self.max_delay, len(Y_init))
            Y_pred[:k0, :] = np.asarray(Y_init)[:k0, :]

        # clipping bounds (3× training range) – only active for poly_degree > 1
        margin = 3.0
        y_lo = self._y_min - margin * (self._y_max - self._y_min + 1e-8)
        y_hi = self._y_max + margin * (self._y_max - self._y_min + 1e-8)

        for t in range(self.max_delay, n):
            for out_idx in range(self.n_outputs):
                na_mode = self._get_na_for_mode(out_idx)
                n_reg = na_mode * self.n_outputs + self.nb
                x = np.zeros(n_reg)
                r = 0
                for mode_idx in range(self.n_outputs):
                    for j in range(na_mode):
                        x[r] = Y_pred[t - 1 - j, mode_idx]
                        r += 1
                for j in range(self.nb):
                    x[r] = u[t - self.nk - j]
                    r += 1
                x_row = self._transform_poly(x.reshape(1, -1), out_idx)
                val = self.models[out_idx].predict(x_row)[0]
                if self.poly_degree > 1:
                    val = np.clip(val, y_lo[out_idx], y_hi[out_idx])
                Y_pred[t, out_idx] = val

        return Y_pred


# ---------------------------------------------------------------------------
# POD utilities
# ---------------------------------------------------------------------------

def _compute_minmax_scaler(states_list):
    """
    Compute per-feature min/max across all training snapshots.

    Parameters
    ----------
    states_list : list of arrays, each shape (n_features * n_cells, n_timesteps)

    Returns
    -------
    f_min, f_max : arrays of shape (n_features * n_cells,)
    """
    all_states = np.concatenate(states_list, axis=1)  # (n_rows, total_timesteps)
    f_min = all_states.min(axis=1)
    f_max = all_states.max(axis=1)
    return f_min, f_max


def _scale(state, f_min, f_max):
    """Map state into [0, 1] column-wise using precomputed min/max."""
    denom = f_max - f_min
    denom[denom == 0.0] = 1.0  # avoid division by zero for constant fields
    return (state - f_min[:, None]) / denom[:, None]


def _unscale(state_scaled, f_min, f_max):
    """Inverse of _scale."""
    denom = f_max - f_min
    denom[denom == 0.0] = 1.0
    return state_scaled * denom[:, None] + f_min[:, None]


def _compute_pod_basis(scaled_states_list, n_modes):
    """
    Compute the POD basis from a list of scaled snapshot matrices.

    Concatenates all snapshots, runs SVD, returns the first n_modes
    left-singular vectors as columns.

    Parameters
    ----------
    scaled_states_list : list of (n_rows, n_timesteps_i) arrays
    n_modes            : int

    Returns
    -------
    Phi : (n_rows, n_modes)  – POD basis (orthonormal columns)
    """
    S = np.concatenate(scaled_states_list, axis=1)  # (n_rows, total_t)
    # economy SVD – we only need the first n_modes left vectors
    U, _, _ = randomized_svd(S, n_components=n_modes, n_iter=4, random_state=42)
    return U  # già (n_rows, n_modes)


def _project(state, Phi):
    """Project physical state onto POD basis. Returns (n_modes, n_t)."""
    return Phi.T @ state  # (n_modes, n_t)


def _reconstruct(coords, Phi):
    """Reconstruct physical state from modal coordinates. Returns (n_rows, n_t)."""
    return Phi @ coords  # (n_rows, n_t)


# ---------------------------------------------------------------------------
# Main model class (ingestion-program interface)
# ---------------------------------------------------------------------------

class model:
    """
    POD-ARX reduced-order model.

    Interface required by the CYPHER 2026 ingestion program:
        preprocess(data_folder) -> D
        fit(D)                  -> None
        predict(test_folder)    -> np.ndarray (n_features * n_cells, n_timesteps)
    """

    # Hyper-parameters (mirror of sum_sin_cut preset in handoff config)
    N_MODES    = 8
    NA         = 5
    NB         = 1
    NK         = 1
    USE_RIDGE  = False
    ALPHA      = 0.0
    POLY_DEG   = 1

    def __init__(self):
        # Set during fit; exposed for predict
        self.f_min   = None   # (n_rows,) minmax scaler
        self.f_max   = None
        self.Phi     = None   # (n_rows, N_MODES) POD basis
        self.arx     = None   # SimpleMIMOARX instance

    # ------------------------------------------------------------------
    # 1. preprocess
    # ------------------------------------------------------------------

    def preprocess(self, data_folder):
        """
        Load all training simulations from data_folder (the "train/" directory).

        Parameters
        ----------
        data_folder : str  – path to the train/ directory

        Returns
        -------
        D : dict with keys
            "states" : list of (n_rows, n_timesteps) arrays  – raw physical states
            "phis"   : list of (n_timesteps,) arrays         – forcing signals
        """
        states = []
        phis   = []

        sim_dirs = sorted([
            d for d in os.listdir(data_folder)
            if os.path.isdir(os.path.join(data_folder, d))
        ])

        if not sim_dirs:
            raise RuntimeError(f"No simulation sub-directories found in {data_folder}")
        
        print(f"[PREPROCESS] Found simulation dirs: {sim_dirs}")

        for sim in sim_dirs:
            sim_path   = os.path.join(data_folder, sim)
            state_file = os.path.join(sim_path, "state.npz")
            phi_file   = os.path.join(sim_path, "phi.npz")

            if not os.path.isfile(state_file) or not os.path.isfile(phi_file):
                warnings.warn(f"Skipping {sim}: missing state.npz or phi.npz")
                continue

            state = np.load(state_file)["data"]   # (n_rows, n_timesteps)
            phi   = np.load(phi_file)["data"]     # (n_timesteps,)

            print(f"[PREPROCESS]   {sim}: state={state.shape}, phi={phi.shape}")

            states.append(state)
            phis.append(phi)

        if not states:
            raise RuntimeError("No valid training simulations could be loaded.")
        print(f"[PREPROCESS] Done. {len(states)} simulations loaded.")

        return {"states": states, "phis": phis}

    # ------------------------------------------------------------------
    # 2. fit
    # ------------------------------------------------------------------

    def fit(self, D):
        """
        Compute the POD basis and fit the ARX model.

        Steps
        -----
        1. Minmax-scale each snapshot matrix (species_minmax).
        2. Compute POD basis via SVD on the concatenated snapshot matrix.
        3. Project all training trajectories onto the POD basis.
        4. Concatenate all reduced-space trajectories and fit a single
           MIMO-ARX model.

        Parameters
        ----------
        D : dict returned by preprocess()
        """
        states = D["states"]   # list of (n_rows, n_t_i)
        phis   = D["phis"]     # list of (n_t_i,)

        # --- 1. Fit scaler on all training data ---
        self.f_min, self.f_max = _compute_minmax_scaler(states)

        print(f"[FIT] Scaler computed. f_min={self.f_min.shape}, f_max={self.f_max.shape}")

        # --- 2. Scale and build POD basis ---
        scaled = [_scale(s, self.f_min, self.f_max) for s in states]
        self.Phi = _compute_pod_basis(scaled, self.N_MODES)   # (n_rows, N_MODES)

        print(f"[FIT] POD basis computed. Phi={self.Phi.shape}")

        # --- 3. Project each simulation onto the POD basis ---
        #    modal_coords[i] : (n_t_i, N_MODES)  (time-first for ARX)
        modal_coords = [_project(s, self.Phi).T for s in scaled]

        # --- 4. Concatenate trajectories and fit ARX ---
        Y_train = np.concatenate(modal_coords, axis=0)          # (total_t, N_MODES)
        u_train = np.concatenate(phis, axis=0)                   # (total_t,)

        print(f"[FIT] Reduced coords: Y_train={Y_train.shape}, u_train={u_train.shape}")

        self.arx = SimpleMIMOARX(
            na          = self.NA,
            nb          = self.NB,
            nk          = self.NK,
            n_outputs   = self.N_MODES,
            use_ridge   = self.USE_RIDGE,
            alpha       = self.ALPHA,
            poly_degree = self.POLY_DEG,
        )
        self.arx.fit(u_train, Y_train)

    # ------------------------------------------------------------------
    # 3. predict
    # ------------------------------------------------------------------

    def predict(self, test_data_folder):
        """
        Predict the full state trajectory for a single test/valid simulation.

        The simulation folder must contain:
            initial_state.npz  – shape (n_rows,)
            phi.npz            – shape (n_timesteps,)

        Returns
        -------
        state_pred : np.ndarray, shape (n_rows, n_timesteps)
        """
        # --- Load inputs ---
        initial_state = np.load(
            os.path.join(test_data_folder, "initial_state.npz")
        )["data"]                                              # (n_rows,)
        phi = np.load(
            os.path.join(test_data_folder, "phi.npz")
        )["data"]                                              # (n_timesteps,)

        n_timesteps = len(phi)

        # --- Scale initial state ---
        # initial_state is (n_rows,); reshape to (n_rows, 1) for _scale
        init_scaled = _scale(initial_state[:, None], self.f_min, self.f_max)  # (n_rows, 1)

        # --- Project initial state onto POD basis ---
        q0 = self.Phi.T @ init_scaled[:, 0]                    # (N_MODES,)

        # --- Build warm-start buffer from initial snapshot ---
        # Replicate q0 for the first max_delay steps so the ARX has
        # something to look back on (matches warm_start_test=True behaviour).
        max_delay = self.arx.max_delay
        Y_init = np.tile(q0, (max_delay, 1))                   # (max_delay, N_MODES)

        # --- Free-run simulation in reduced space ---
        Y_pred = self.arx.predict_sim(phi, Y_init=Y_init)      # (n_timesteps, N_MODES)

        # --- Reconstruct physical state ---
        # _reconstruct expects (N_MODES, n_timesteps)
        state_scaled_pred = _reconstruct(Y_pred.T, self.Phi)   # (n_rows, n_timesteps)

        # --- Inverse scaling ---
        state_pred = _unscale(state_scaled_pred, self.f_min, self.f_max)

        return state_pred                                        # (n_rows, n_timesteps)
